Welcome to awesomeness!

This exploit was created by: INfoUpgraders#2151
It uses WeAreDevsAPI (for now :p)
If there are ever any bugs, please let me know on Discord

NOTE: This exploit offers updates, it will let you know when it is ready to be updated next!

Enjoy! ~ INfoUpgraders#2151