local Player   = game.Players.LocalPlayer

repeat wait() until Player.Character

local StoredCF = Player.Character:WaitForChild('Head').CFrame
local IsTPing  = false

local function GetPlayer(String)
   String = String or 'N/A'

   for i,v in pairs(game.Players:GetPlayers()) do
       if v.Name:lower():match('^'..String:lower()) then
           return v
       end
   end

   return false
end

Player.CharacterAdded:connect(function(Char)
   if IsTPing then
       IsTPing = false
       Char:WaitForChild('Head').CFrame = StoredCF
   end
end)

Player.Chatted:connect(function(Message)
   local Target   = GetPlayer(Message:match(':fling%s*(.+)'))
   local HasDied  = false
   local PPart    = Player.Character.PrimaryPart

   StoredCF = PPart.CFrame

   if not Target then
       return
   end

   repeat wait() until Target.Character

   IsTPing = true

   Target.Character:WaitForChild('Humanoid').Died:connect(function()
       HasDied = true
   end)

   local bodyp    = Instance.new("BodyPosition",PPart)
   bodyp.D        = 0
   bodyp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)

   repeat
       game:GetService("RunService").RenderStepped:Wait()
       pcall(function()
           bodyp.Position = Target.Character.PrimaryPart.Position
       end)
   until

       HasDied == true

   pcall(function()
       bodyp:Destroy()
       Player.Character:BreakJoints()
   end)

   print('Killed')

end)